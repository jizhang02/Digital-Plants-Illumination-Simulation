#include <iostream>
#include"raytracer.h"
#include<string>
#include<ctime>
using namespace std;
int main()
{
    double start_time = clock();

    Raytracer* raytracer = new Raytracer;
    raytracer->SetInput("scene.txt");
    raytracer->SetOutput("picture.bmp");
    raytracer->Run();
    delete raytracer;

    double end_time = clock();
    printf("Escaped time: %.5lf\n", (end_time - start_time)/CLOCKS_PER_SEC);
    return 0;
}
